/*****************************************************************************
  FILE           : $Source: /projects/higgs1/SNNS/CVS/SNNS/xgui/sources/bn_TD_bignet.h,v $
  SHORTNAME      : bn_TD_bignet
  SNNS VERSION   : 4.2
  PURPOSE        : 
  NOTES          :
  AUTHOR         : Guenter Mamier
  DATE           : 09.02.93
  CHANGED BY     : 
  RCS VERSION    : $Revision: 2.6 $
  LAST CHANGE    : $Date: 1998/02/25 15:19:26 $
    Copyright (c) 1990-1995  SNNS Group, IPVR, Univ. Stuttgart, FRG
    Copyright (c) 1996-1998  SNNS Group, WSI, Univ. Tuebingen, FRG
******************************************************************************/
#ifndef _BN_TD_BIGNET_DEFINED_
#define  _BN_TD_BIGNET_DEFINED_
void bn_create_TD_Bignet (void);
#endif 
/* end of file */
/* lines: 27 */
