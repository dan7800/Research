#!/bin/bash
find -type f -name "*.class" -exec rm {} \;

