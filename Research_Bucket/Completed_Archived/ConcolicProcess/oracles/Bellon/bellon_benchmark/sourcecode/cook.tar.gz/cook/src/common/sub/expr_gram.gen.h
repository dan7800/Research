typedef union {
       long  lv_number;
} sub_expr_gram_STYPE;
#define        DIV    258
#define        JUNK   259
#define        LP     260
#define        MINUS  261
#define        MUL    262
#define        NUMBER 263
#define        PLUS   264
#define        RP     265
#define        UNARY  266
extern sub_expr_gram_STYPE sub_expr_gram_lval;
