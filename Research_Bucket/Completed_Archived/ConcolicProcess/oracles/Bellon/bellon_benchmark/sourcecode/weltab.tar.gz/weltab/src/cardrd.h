/* cardrd */
char card[81];
