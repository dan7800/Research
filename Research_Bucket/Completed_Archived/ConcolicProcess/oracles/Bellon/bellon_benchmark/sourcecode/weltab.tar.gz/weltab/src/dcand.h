/* dcand */
char dcname[25];
