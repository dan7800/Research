/* candnm */
char candnm[25],partnm[3];
