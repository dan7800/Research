/* offnam */
char offnam[50];
char dualnm[50];
