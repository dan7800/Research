/* unitinfo */
char uncode[2],unitnm[20];
int untnprec, untstart, untavcbs;
LOGICAL untwards, untsplit;
/* definitions for untavcbs values */
#define NONE   0
#define EXISTS 1
#define BYWARD 2
