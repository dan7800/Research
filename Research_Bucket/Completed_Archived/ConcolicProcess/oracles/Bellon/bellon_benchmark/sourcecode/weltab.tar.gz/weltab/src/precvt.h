/* precvt */
int vtindx;
int vtunit;
long int vtprec;
long int vtpoll;
long int vote[MAXCAND];
char entrer[8];
char verifr[8];
char vtdate[12];
char vttime[8];
