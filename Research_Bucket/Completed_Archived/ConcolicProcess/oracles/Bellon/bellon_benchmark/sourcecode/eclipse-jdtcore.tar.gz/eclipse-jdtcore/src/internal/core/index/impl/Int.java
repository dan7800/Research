package org.eclipse.jdt.internal.core.index.impl;
/*
 * (c) Copyright IBM Corp. 2000, 2001.
 * All Rights Reserved.
 */
import org.eclipse.jdt.core.*;
public class Int {
       public int value;
       /**
        * Int constructor comment.
        */
       public Int(int i) {
             value= i; } }
