package jp.ac.osaka_u.ist.sdl.scorpio.settings;

public enum HEURISTICS {

	ON {
	},

	OFF {
	};
}
