package jp.ac.osaka_u.ist.sdl.scorpio;


public interface Entity {

}
