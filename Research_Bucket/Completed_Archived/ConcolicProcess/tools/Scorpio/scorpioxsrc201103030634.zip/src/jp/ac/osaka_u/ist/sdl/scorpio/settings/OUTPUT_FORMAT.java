package jp.ac.osaka_u.ist.sdl.scorpio.settings;

public enum OUTPUT_FORMAT {

	SET {

	},

	PAIR {

	};
}
