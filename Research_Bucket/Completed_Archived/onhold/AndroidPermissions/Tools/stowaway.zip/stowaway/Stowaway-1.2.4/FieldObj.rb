#
#  FieldObj.rb
#  
#
#  Created by Erika Chin on 11/1/10.
#  Copyright (c) 2010 __MyCompanyName__. All rights reserved.
#

class FieldObj
attr_accessor :name, :objType, :value, :inClass

def initialize(nam, cls, oType)
	@name="#{cls}.#{nam}"
	@objType=oType
	@inClass = cls
	
	@value=""

end

def getType()
	return @objType
end
def setType(type)
	@objType = type
end


end
