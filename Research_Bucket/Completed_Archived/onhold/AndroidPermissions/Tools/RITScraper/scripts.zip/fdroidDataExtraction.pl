#!/usr/bin/perl

use strict;
use warnings;

use LWP::Simple;
use HTML::Tree;

my $htmlPrefix = "http://fdroid.org";

&initializeFiles;


# For each html page, call 
# extractFromFdroid to get 
# wiki links into output.txt
my $page = "F-Droid1.html";		#edit here for the name of the html page you saved
&extractFromFdroid; 

$page = "F-Droid2.html";   		# For each page saved, change the $page variable
&extractFromFdroid;				# and call $extractFromFdroid


#call printSourceLinks to collect
#all the source links into projects.txt

&printSourceLinks;

sub initializeFiles{
	open(OUTPUT, ">output.txt");
	close(OUTPUT);
	open(PROJECT, ">projects.txt");
	close(PROJECT);
}

#method will print wiki links depending on the $page variable
#list of wiki links will be in output.txt
sub extractFromFdroid{

	open(my $fh, "<", $page)
    	or die "cannot open < input.txt: $!";
	my $content = join('',<$fh>);
	open(OUTPUT, ">>output.txt");
	my $tree = HTML::Tree->new();

	$tree->parse($content);

	my @tags = $tree->look_down('_tag', 'a');

	my $temp = "";
	my $webpage = "";

	foreach (@tags) {
		$temp = $_->attr('href');
		if(index($temp, "wiki/page") != -1  
			and index($temp, ":") == -1
			and index($temp, "Main_Page") == -1 ) {
		

		$temp = $htmlPrefix.$temp;
		print OUTPUT $temp . "\n";	

		} 
	
	}
	close($fh);
}

#method will print source code links given list of wiki links in output.txt
#list of links will be in projects.txt
sub printSourceLinks{
	my $urlFile = "output.txt";

	open(my $fh, "<", $urlFile);

	my @lines = <$fh>;
	my $browser = LWP::UserAgent->new;
	my $response;
	my $tree;
	open(MYFILE, ">reponse.html");

	open(PROJECT, ">projects.txt");

	foreach my $line(@lines) {
		
		$response = $browser->get($line);
		$tree = HTML::Tree->new();
		$tree->parse($response->content);
		
		my @atag = $tree->look_down('_tag', 'p');

		foreach my $at(@atag) {
			if(index($at->as_text(), "Source: ") != -1) {
				print PROJECT $at->as_text()."\n";
					
			}
		}	

	}
	close(PROJECT);

	close(MYFILE);
	close($fh);
}
