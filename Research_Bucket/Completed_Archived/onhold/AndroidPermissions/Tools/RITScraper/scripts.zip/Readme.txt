1. Introduction

For each application on f-droid, there is an auto-generated wiki page.
On that wiki page, a link to the source code repository is placed.
On the F-droid wiki site (not the main site), we can use the search
results to return all the wiki page links. The way my script works is 
using the search results, the script will visit each of the wiki pages
and extract the source link into a file.


2. Usage 

First, a little manual labor is required. The link below will take
you to the search results of all the applications.

https://f-droid.org/wiki/index.php?title=Category:Apps

Save the results page as an html page. I couldn't figure out a
way for the wiki to display all the application results on a single
page, so I saved each 200 links page. When I was collecting 
data, I saved 9 pages worth of links.

Second, fdroidDataExtraction.pl must be edited. The $page variable
must be assigned with the name of the html page you saved as. Then
extractFromFdroid function must be called right after the $page variable
is changed.

It takes a good couple of minutes for the script to finish completely.
When it's done, two files should be produced. output.txt lists all
the wiki page links, and projects.txt should contain all the source
code links. To make sure the scripts work, I've also attached FDroid1.html
and FDroid2.html as examples. If you run the script as is, everything
should run fine.

The script was created in linux. Usage is as follows:

perl fdroidDataExtraction.pl

Make sure the script file is placed in the same directory as the html files!


3. Files included:
	-fdroidDataExtraction.pl
	-F-Droid1.html
	-F-Droid2.html
